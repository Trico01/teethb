export declare function transition(showDefaultValue: boolean): string;
